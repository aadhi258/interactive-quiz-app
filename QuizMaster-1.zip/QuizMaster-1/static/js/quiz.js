// Quiz Application JavaScript

// Global variables (avoid conflicts with inline scripts)
window.quizGlobals = window.quizGlobals || {
    currentQuestion: 0,
    totalQuestions: 0,
    userAnswers: {},
    quizStartTime: null
};

// Initialize quiz when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeQuiz();
    setupEventListeners();
});

// Initialize quiz functionality
function initializeQuiz() {
    const questionCards = document.querySelectorAll('.question-card');
    totalQuestions = questionCards.length;
    
    if (totalQuestions > 0) {
        quizStartTime = new Date();
        showQuestion(0);
        updateProgress();
    }
    
    // Auto-save answers in localStorage
    loadSavedAnswers();
}

// Setup event listeners
function setupEventListeners() {
    // Radio button change events
    const radioButtons = document.querySelectorAll('input[type="radio"]');
    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            saveAnswer(this);
            updateProgress();
        });
    });
    
    // Form submission
    const quizForm = document.getElementById('quiz-form');
    if (quizForm) {
        quizForm.addEventListener('submit', handleQuizSubmission);
    }
    
    // Keyboard navigation
    document.addEventListener('keydown', handleKeyboardNavigation);
    
    // Prevent accidental page refresh
    window.addEventListener('beforeunload', function(e) {
        if (Object.keys(userAnswers).length > 0) {
            e.preventDefault();
            e.returnValue = '';
        }
    });
}

// Show specific question
function showQuestion(questionIndex) {
    const questions = document.querySelectorAll('.question-card');
    
    // Hide all questions
    questions.forEach(q => q.style.display = 'none');
    
    // Show current question
    if (questions[questionIndex]) {
        questions[questionIndex].style.display = 'block';
        currentQuestion = questionIndex;
        
        // Update navigation buttons
        updateNavigationButtons();
        
        // Update progress
        updateProgress();
        
        // Focus on first radio button for accessibility
        const firstRadio = questions[questionIndex].querySelector('input[type="radio"]');
        if (firstRadio) {
            firstRadio.focus();
        }
    }
}

// Update navigation buttons
function updateNavigationButtons() {
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const submitBtn = document.getElementById('submit-btn');
    
    if (prevBtn) {
        prevBtn.disabled = currentQuestion === 0;
    }
    
    if (nextBtn && submitBtn) {
        if (currentQuestion === totalQuestions - 1) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-block';
        } else {
            nextBtn.style.display = 'inline-block';
            submitBtn.style.display = 'none';
        }
    }
}

// Update progress bar
function updateProgress() {
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    
    if (progressBar && progressText) {
        const progress = ((currentQuestion + 1) / totalQuestions) * 100;
        progressBar.style.width = progress + '%';
        progressText.textContent = (currentQuestion + 1) + '/' + totalQuestions;
        
        // Update progress bar color based on completion
        if (progress >= 100) {
            progressBar.classList.add('bg-success');
        } else if (progress >= 50) {
            progressBar.classList.add('bg-warning');
        }
    }
}

// Navigate to next question
function nextQuestion() {
    if (currentQuestion < totalQuestions - 1) {
        currentQuestion++;
        showQuestion(currentQuestion);
        
        // Smooth scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Navigate to previous question
function previousQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        showQuestion(currentQuestion);
        
        // Smooth scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Save user answer
function saveAnswer(radioElement) {
    const questionId = radioElement.getAttribute('data-question') || 
                       radioElement.name.replace('question_', '');
    const answerId = radioElement.value;
    
    userAnswers[questionId] = answerId;
    
    // Save to localStorage
    localStorage.setItem('quizAnswers', JSON.stringify(userAnswers));
}

// Load saved answers from localStorage
function loadSavedAnswers() {
    const savedAnswers = localStorage.getItem('quizAnswers');
    if (savedAnswers) {
        try {
            userAnswers = JSON.parse(savedAnswers);
            
            // Restore radio button selections
            Object.keys(userAnswers).forEach(questionId => {
                const radio = document.querySelector(`input[value="${userAnswers[questionId]}"]`);
                if (radio) {
                    radio.checked = true;
                }
            });
        } catch (e) {
            console.error('Error loading saved answers:', e);
        }
    }
}

// Handle keyboard navigation
function handleKeyboardNavigation(event) {
    // Only handle keyboard navigation on quiz page
    if (!document.querySelector('.question-card')) return;
    
    switch(event.key) {
        case 'ArrowRight':
            if (currentQuestion < totalQuestions - 1) {
                nextQuestion();
            }
            break;
        case 'ArrowLeft':
            if (currentQuestion > 0) {
                previousQuestion();
            }
            break;
        case '1':
        case '2':
        case '3':
        case '4':
            // Quick answer selection
            const questionCard = document.querySelector('.question-card:not([style*="display: none"])');
            if (questionCard) {
                const radios = questionCard.querySelectorAll('input[type="radio"]');
                const radioIndex = parseInt(event.key) - 1;
                if (radios[radioIndex]) {
                    radios[radioIndex].checked = true;
                    saveAnswer(radios[radioIndex]);
                    updateProgress();
                }
            }
            break;
        case 'Enter':
            // Submit quiz or go to next question
            if (currentQuestion === totalQuestions - 1) {
                const submitBtn = document.getElementById('submit-btn');
                if (submitBtn) {
                    submitBtn.click();
                }
            } else {
                nextQuestion();
            }
            break;
    }
}

// Handle quiz submission
function handleQuizSubmission(event) {
    const form = event.target;
    const formData = new FormData(form);
    
    // Validate all questions are answered
    const unansweredQuestions = [];
    const radioGroups = {};
    
    // Group radio buttons by question
    const radios = form.querySelectorAll('input[type="radio"]');
    radios.forEach(radio => {
        const questionName = radio.name;
        if (!radioGroups[questionName]) {
            radioGroups[questionName] = [];
        }
        radioGroups[questionName].push(radio);
    });
    
    // Check if each question has an answer
    Object.keys(radioGroups).forEach((questionName, index) => {
        const isAnswered = radioGroups[questionName].some(radio => radio.checked);
        if (!isAnswered) {
            unansweredQuestions.push(index + 1);
        }
    });
    
    if (unansweredQuestions.length > 0) {
        event.preventDefault();
        
        // Show alert with unanswered questions
        const message = `Please answer all questions before submitting.\n\nUnanswered questions: ${unansweredQuestions.join(', ')}`;
        alert(message);
        
        // Navigate to first unanswered question
        showQuestion(unansweredQuestions[0] - 1);
        return false;
    }
    
    // Calculate time taken
    const endTime = new Date();
    const timeTaken = Math.round((endTime - quizStartTime) / 1000); // in seconds
    
    // Add hidden field for time taken
    const timeField = document.createElement('input');
    timeField.type = 'hidden';
    timeField.name = 'time_taken';
    timeField.value = timeTaken;
    form.appendChild(timeField);
    
    // Show confirmation dialog
    const confirmed = confirm('Are you sure you want to submit your quiz? You cannot change your answers after submission.');
    
    if (confirmed) {
        // Clear saved answers
        localStorage.removeItem('quizAnswers');
        
        // Show loading state
        const submitBtn = document.getElementById('submit-btn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Submitting...';
        }
        
        return true;
    } else {
        event.preventDefault();
        return false;
    }
}

// Utility functions
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

// Quiz management functions
function confirmDelete(message) {
    return confirm(message || 'Are you sure you want to delete this item?');
}

// Auto-save functionality for quiz creation
function autoSaveQuiz() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                const formData = new FormData(form);
                const data = {};
                for (let [key, value] of formData.entries()) {
                    data[key] = value;
                }
                localStorage.setItem('quizDraft', JSON.stringify(data));
            });
        });
    });
}

// Load quiz draft
function loadQuizDraft() {
    const draftData = localStorage.getItem('quizDraft');
    if (draftData) {
        try {
            const data = JSON.parse(draftData);
            Object.keys(data).forEach(key => {
                const input = document.querySelector(`[name="${key}"]`);
                if (input) {
                    input.value = data[key];
                }
            });
        } catch (e) {
            console.error('Error loading quiz draft:', e);
        }
    }
}

// Clear quiz draft
function clearQuizDraft() {
    localStorage.removeItem('quizDraft');
}

// Initialize auto-save on quiz creation pages
if (window.location.pathname.includes('create') || window.location.pathname.includes('manage')) {
    document.addEventListener('DOMContentLoaded', function() {
        autoSaveQuiz();
        loadQuizDraft();
    });
}
